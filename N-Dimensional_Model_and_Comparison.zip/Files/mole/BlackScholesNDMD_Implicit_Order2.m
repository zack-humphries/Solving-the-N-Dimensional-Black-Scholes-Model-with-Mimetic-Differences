%% N-D Black-Scholes PDE
% Zachary Humphries
% COMP 797 - Dr. Miguel Dumett
% Fall 2023

clear all;
close all;
clc;


%% Parameters
T = 1;                                      % Time
strike = 1;                                 % Strike Price
r = 0.1;                                    % Risk free interest rate

k = 2;                                      % Order of accuracy

%% Omega Matrix (must be square and diagonal)

omega = [0.1 0.1 0.1;
    0.1 0.1 0.1;
    0.1 0.1 0.1];

% omega = [0.10 0.10 0.10 0.10;
%          0.10 0.10 0.10 0.10;
%          0.10 0.10 0.10 0.10;
%          0.10 0.10 0.10 0.10;];

%% Do not edit code below

%% Set up Dimensions
dimensions = length(omega);
n = (4*k)^2 +1;                             % 2*k+1 = Minimum number of cells to attain the desired accuracy

n = 5;

minValue = 0;
maxValue = 5*strike*dimensions;

dn = (maxValue-minValue)/n;

grid1D = [minValue minValue+dn/2 : dn : maxValue-dn/2 maxValue];

NdArrays = cell(dimensions, 1);  %create cell array to receive outputs of ndgrid

[NdArrays{:}] = ndgrid(grid1D);  %fills all N Nd arrays

%% Time

dt = 0.05*(dimensions*(1/dn)^2)^(-1);       % Von Neumann stability criterion for explicit scheme dx^2/(4*alpha)
dt = -dt;

%% Initial Conditions

Fzeros = zeros(size(NdArrays{1}));

Fsum = Fzeros;
for ii = 1:dimensions

    Fsum = NdArrays{ii} + Fsum;

end

F = max((Fsum./dimensions) - strike, Fzeros);
Fvec = reshape(F, (n+2)^dimensions, 1);

NdVec = cell(dimensions, 1);

for ii = 1:dimensions

    NdVec{ii} = reshape(NdArrays{ii}, (n+2)^dimensions, 1);

end

%% Plot Initial Conditions

plotBlackScholes(Fvec, size(F), NdArrays, n, T, minValue, maxValue, strike);

%% operator maticies
small_I = speye((n+2)^(dimensions), (n+2)^(dimensions));
I = speye(dimensions*((n+2)^(dimensions)), dimensions*((n+2)^(dimensions)));

NdI = cell(dimensions, 1);
for ii = 1:dimensions

    NdI{ii} = NdVec{ii} .* small_I; % length is (n+2)^(dimensions)

end

NDI = [cat(1, NdVec{:})] .* I;  % length is dimensions*(n+2)^(dimensions)

ND = [NdI{:}];

%O = sparse([], length(omega)*length(small_I), length(omega)*length(small_I));
O = kron(omega.*omega, small_I);

%% Setting Up Gradient and Divergence Matricies

% G = grad2D(k, m, dx, n, dy);
% D = div2D(k, m, dx, n, dy);

G = [];
D = [];

%% Setting Up Interpolation Matrices

% IFC = interpolFacesToCentersG2D(k, m, n);
% ICF = interpolCentersToFacesD2D(k, m, n);

IFC = [];
ICF = [];

%% Combine for Black-Scholes Matrix

A1 = -(r*ND*IFC*G);
A2 = -0.5*(D*ICF*NDI*O*NDI*IFC*G);
A3 = r*small_I;

A = A1+A2+A3;


%% auxiliary variables
len = length(T : dt : 0);
Fsol = zeros(numel(Fvec), len); % to store solutions
Fsol(:,1) = Fvec;

Faux = Fvec; % to jump start time discretization

%% Forward Euler (First Order)

Faux = (small_I - dt*A)\(Fsol(:,1));

Faux(1) = 0;

Fsol(:,2) = Faux;

%% Forward Euler
count = 2;
for t = T+(2*dt) : dt : 0

    Faux = (small_I - ((2*dt)/3)*A)\((4/3)*Fsol(:,count) - (1/3)*Fsol(:, count-1));
    

%    plotBlackScholes(Faux, X, Y, m, n, t, a, b, c, d, strike);

    count = count+1;
    Fsol(:,count) = Faux;

end

figure(2)
plotBlackScholes(Faux, X, Y, m, n, 0, a, b, c, d, strike);


function plotBlackScholes(Fvec, sizeFvec, NdArrays, n, t, minValue, maxValue, strike)
    F = reshape(Fvec, sizeFvec);

    tempNdArrays = cell(length(NdArrays)-1, 1);

    sliderValues = [NdArrays{3}(1,1,:)];

    Fslice = squeeze(F(:,:, 1));

    for ii = 1:(length(NdArrays)-1)
        tempNdGrid = NdArrays{ii};
        tempNdArrays{ii} = squeeze(tempNdGrid(:,:, 1));
    end
    
    currFig = surf(tempNdArrays{1}, tempNdArrays{2}, Fslice);
%     set(currFig, 'title', ['2D Black-Scholes \newlineTime = ' num2str(t, '%1.4f')],...
%         'xlabel', 'x', 'ylabel', 'y', 'zlabel', 'F', 'axis', [minValue maxValue minValue maxValue])
    title(['2D Black-Scholes \newlineTime = ' num2str(t, '%1.2f') ', z = ' num2str(sliderValues(1), '%2.2f')]);
    xlabel('x');
    ylabel('y');
    zlabel('F');
    colorbar;
    caxis([minValue maxValue])
    axis([minValue maxValue minValue maxValue minValue maxValue]);
    drawnow

    uicontrol('Style', 'slider', 'Min', 1, 'Max', length(sliderValues), ...
       'Value', 1, 'Position', [400 20 130 20], ...
       'Callback', @react_to_slider);

    drawnow

        function react_to_slider(source, event)   %nested !!
            val = round(get(source, 'Value'));
            if val >= length(sliderValues)
                val = length(sliderValues);
            end
            set(source, 'Value', val);
            plotGraph(val)
          

            function plotGraph(val)
                Fslice = squeeze(F(:,:, val));

                for jj = 1:(length(NdArrays)-1)
                    tempNdGrid = NdArrays{jj};
                    tempNdArrays{jj} = squeeze(tempNdGrid(:,:, val));
                end

                set(currFig, 'XData', tempNdArrays{1}, 'YData', tempNdArrays{2}, 'ZData', Fslice);
                title(['2D Black-Scholes \newlineTime = ' num2str(t, '%1.2f') ', z = ' num2str(sliderValues(val), '%2.2f')]);
                drawnow

            end
            
        end


  
end


