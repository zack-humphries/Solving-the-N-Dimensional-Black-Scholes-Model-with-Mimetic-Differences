function XY = bottom(s)
    X = 2*cos(pi/2*(1-2*s));
    Y = sin(pi/2*(1-2*s));
    XY = [X Y];
end