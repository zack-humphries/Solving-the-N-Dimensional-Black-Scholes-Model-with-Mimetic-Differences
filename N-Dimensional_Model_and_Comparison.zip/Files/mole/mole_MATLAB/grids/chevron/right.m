function XY = right(s)
    X = 1;
    Y = s;
    XY = [X Y];
end