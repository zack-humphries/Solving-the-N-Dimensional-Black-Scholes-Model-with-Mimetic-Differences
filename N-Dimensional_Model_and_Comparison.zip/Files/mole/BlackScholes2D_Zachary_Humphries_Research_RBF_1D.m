%% 1D Black-Scholes RBG
% Zachary Humphries
% COMP 797 - Dr. Miguel Dumett
% Spring 2024

clear all;
close all;
clc;

addpath('C:\Users\14048\Desktop\SDSU\Fall2023\Research\mole\mole_MATLAB')


%% parameters depend on strike price value
T = 1;
strike = 1;                                 % Strike Price
omega = [0.15];
r = 0.03;                                    % Risk free interest rate

k = 2;                                      % Order of accuracy

a = 0;                                      % Minimum Value of Option for Asset X (must be zero)
b = round(4*strike);                       % Maximum Value of Option for Asset X (Recommended between 8*strike and 12*strike)

m = 40; %2*k+1; % max(4* round(10*strike), 2*k+1);        % 2*k+1 = Minimum number of cells to attain the desired accuracy

dx = (b-a)/m;                               % Step length along the x-axis

%dt = 0.05*((1/dx)^2)^(-1); % min(dx^2/4, 0.001); 

dt = 0.05;% Von Neumann stability criterion for explicit scheme dx^2/(4*alpha)

%% mesh
xgrid = [a a+dx/2 : dx : b-dx/2 b];
X = xgrid;

%% initial condition
F = max(X-strike, 0); 

Fvec = F';
Xvec = X';

Tvec = [0:dt:T]';

Fsol = zeros(length(Xvec), length(Tvec));
Fsol(end,:) = boundaryCondition(b, strike, r, T, Tvec)';
Fsol(:,1) = Fvec;
Fsol


%% Close-Field Boundary Condition

function L = BlackScholes1D(k, m, dx, xgrid, r, omega)

    Gx = grad(k, m, dx);

    IFCx = interpolFacesToCentersG1D(k,m);

    Lx = lap(k, m, dx);

    Ix = speye((m+2), (m+2));

    XI = diag(xgrid);

    L = ((-r*XI*IFCx*Gx) - (omega(1,1)*omega(1,1)/2 * XI*XI * Lx) + r*Ix); 
end

function BCvec = boundaryCondition(b, strike, r, T, Tvec)

    BCvec = b - strike*exp(-r*(Tvec));

end

function Pvec = RBFunction(epsilon, r)
    Pvec = exp((epsilon * r).^2);
end

