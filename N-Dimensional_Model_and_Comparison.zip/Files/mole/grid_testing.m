
clear all;
close all;
clc;

a = 0;                                      % Minimum Value of Option for Asset X (must be zero)
b = round(10);                       % Maximum Value of Option for Asset X (Recommended between 8*strike and 12*strike)
c = 0;                                      % Minimum Value of Option for Asset Y (must be zero)
d = b;                                      % Maximum Value of Option for Asset X

dx = 1;
dy = 1;

% mesh
xgrid = [a a+dx/2 : dx : b-dx/2 b];
ygrid = [c c+dy/2 : dy : d-dy/2 d];
[X, Y] = meshgrid(xgrid, ygrid);

% mesh 2
xgridEdge = [a: dx: b];
ygridEdge = [c : dy : d];
[Xedge, Yedge] = meshgrid(xgridEdge, ygridEdge);

% same values
sameGrid = zeros(2,2);
sameGrid(1,1) = a;
sameGrid(1,end) = b;
sameGrid(end, 1) = c;
sameGrid(end, end) = d;
XsameGrid = [0,0;b,d];

scatter(Xedge,Yedge, "red", 'LineWidth',1.5)
xline(xgridEdge,'--')
yline(ygridEdge,'--')
hold on
scatter(X,Y, 'MarkerEdgeColor',[0.5 .5 .5], "MarkerFaceColor", [0.5,0.5,0.5], "LineWidth", 0.01)
% hold on
% scatter(XsameGrid, sameGrid, 'MarkerEdgeColor',[0 0 0], "MarkerFaceColor", [0,0,0], 'LineWidth',1.5)
