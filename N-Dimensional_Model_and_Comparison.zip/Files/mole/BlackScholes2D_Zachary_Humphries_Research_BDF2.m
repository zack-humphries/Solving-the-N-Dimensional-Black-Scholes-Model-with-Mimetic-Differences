%% 2D Black-Scholes PDE
% Zachary Humphries
% COMP 670 - Dr. Miguel Dummet
% Fall 2022

clc
clear
close all

% addpath('.../mole_MATLAB')
addpath('C:\Users\14048\Desktop\SDSU\Fall2023\Research\mole\mole_MATLAB')

%% Spatial Discretization

global k m n dx dy dt xgrid ygrid XI YI omega11 omega12 r dirichlet_2D dirichlet_x dirichlet_y

strike = 1;                                 % Strike Price

T = .05;                                      % Simulation time

k = 4;                                      % Order of accuracy

a = 0;                                      % Minimum Value of Option for Asset X (must be zero)
b = round(10*strike);                       % Maximum Value of Option for Asset X (Recommended between 8*strike and 12*strike)
c = 0;                                      % Minimum Value of Option for Asset Y (must be zero)
d = b;                                      % Maximum Value of Option for Asset X

m = max(4* round(10*strike), 2*k+1);        % 2*k+1 = Minimum number of cells to attain the desired accuracy
n = m;                                      % Number of cells along the y-axis

dx = (b-a)/m;                               % Step length along the x-axis
dy = (d-c)/n;                               % Step length along the y-axis

dt = min(dx^2/(6), 0.001);                  % Von Neumann stability criterion for explicit scheme dx^2/(4*alpha)

omega11 = 0.3;                              % Omega_xx = Omega_yy of the volatility correlation matrix
omega12 = 0.05;                             % Omega_xy = Omega_yx of the volatility correlation matrix
r = 0.1;                                    % Risk free interest rate

%% Setting Up Vectors of F, X, and Y

xgrid = [a a+dx/2 : dx : b-dx/2 b];
ygrid = [c c+dy/2 : dy : d-dy/2 d];

[X, Y] = meshgrid(xgrid, ygrid);

F = max(((X+Y)/2)-strike, 0);

Fvec = reshape(F, (m+2)*(n+2), 1);
Xvec = reshape(X, (m+2)*(m+2), 1);
Yvec = reshape(Y, (n+2)*(n+2), 1);

%% Setting Up Identity Matrix (I) and Matrix Representations of 

small_I = speye((m+2)*(m+2), (n+2)*(n+2));
I = speye((m+2)*(m+2)+(n+2)*(n+2), (m+2)*(m+2)+(n+2)*(n+2));

XI = spdiags(Xvec, 0, (m+2)*(m+2), (m+2)*(m+2));
YI = spdiags(Yvec, 0, (n+2)*(n+2), (n+2)*(n+2));

XYI = spdiags([Xvec; Yvec], 0, (m+2)*(m+2)+(n+2)*(n+2), (m+2)*(m+2)+(n+2)*(n+2));

XY = [XI,YI];

%% Setting Up Omega Matrix

O = [omega11*small_I, omega12*small_I; omega12*small_I, omega11*small_I];

%% Setting Up Gradient and Divergence Matricies

G = grad2D(k, m, dx, n, dy);
D = div2D(k, m, dx, n, dy);

%% Setting Up Interpolation Matrices

IFC = interpolFacesToCentersG2D(k, m, n);

ICF = interpolCentersToFacesD2D(k, m, n);

%% Combine for Black-Scholes Matrix

A = -1*((r*XY*IFC*G) + 0.5*(D*ICF*XYI*O*XYI*IFC*G) - r*small_I);

%% Adjust A to Account for Close-Field Boundary Conditions

closeFieldA = closeFieldBC(k, m, n, dx, dy, xgrid, ygrid, r, omega11);

assert(isequal(size(closeFieldA), size(A)));
closeFieldA(closeFieldA == 0) = A(closeFieldA == 0);

A = closeFieldA;

%% Plot Initial Conditions

plotBlackScholes(Fvec, X, Y, m, n, T, 0, strike);

%% Set Up Forward Euler (Order of Accuracy: 1)

t = dt;

time = t;

Fvec_minus1 = A*Fvec;
Fvec_minus1(1,1) = 0;

Fvec_minus1 = reshape(Fvec_minus1, (m+2)*(n+2), 1);
Fvec = reshape(Fvec, (m+2)*(n+2), 1);

Fvec = dt*Fvec_minus1 + Fvec;

Fvec = reshape(Fvec, (m+2), (n+2));

[farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, strike, r, T, time);
Fvec(end, :) = farFieldX';
Fvec(:,end) = farFieldY;
Fvec = reshape(Fvec, (m+2)*(n+2), 1);

Fvec_minus2 = Fvec_minus1;
Fvec_minus1 = Fvec;

%% Next Step

t = 2*dt;
time = t;

Fvec_minus2 = reshape(Fvec_minus2, (m+2)*(n+2), 1);
Fvec_minus1 = reshape(Fvec_minus1, (m+2)*(n+2), 1);


Fvec = ((-2*dt)/(2*dt-3))*((dt*Fvec_minus1 + 2*Fvec_minus1 - Fvec_minus2)/(dt^2));

Fvec = reshape(Fvec, (m+2), (n+2));

[farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, strike, r, T, time);
Fvec(end, :) = farFieldX';
Fvec(:,end) = farFieldY;
Fvec = reshape(Fvec, (m+2)*(n+2), 1);



plotBlackScholes(Fvec, X, Y, m, n, T, t, strike);

Fvec_minus2 = Fvec_minus1;
Fvec_minus1 = Fvec;

%% Forward Euler
count = 1;
len = length(dt : dt : T);
for t = 3*dt : dt : T
    time = t;
    
    Fvec_minus2 = reshape(Fvec_minus2, (m+2)*(n+2), 1);
    Fvec_minus1 = reshape(Fvec_minus1, (m+2)*(n+2), 1);
    
    
    Fvec = ((-2*dt)/(2*dt-3))*((dt*Fvec_minus1 + 2*Fvec_minus1 - Fvec_minus2)/(dt^2));
    
    Fvec = reshape(Fvec, (m+2), (n+2));
    
    [farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, strike, r, T, time);
    Fvec(end, :) = farFieldX';
    Fvec(:,end) = farFieldY;
    Fvec = reshape(Fvec, (m+2)*(n+2), 1);
    
    
    
    plotBlackScholes(Fvec, X, Y, m, n, T, t, strike);
    
    Fvec_minus2 = Fvec_minus1;
    Fvec_minus1 = Fvec;



end



%% Far-Field Coundary Condition

function [farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, K, r, T, t)

    farFieldX = (d + xgrid)/2 - K*exp(-r*(T-t));
    farFieldY = (b + ygrid)/2 - K*exp(-r*(T-t));
    

end

%% Close-Field Boundary Condition

function closeFieldA = closeFieldBC(k, m, n, dx, dy, xgrid, ygrid, r, omega11)

    Gx = grad(k, m, dx);
    Gy = grad(k, n, dy);

    IFCx = interpolFacesToCentersG1D(k,m);
    IFCy = interpolFacesToCentersG1D(k,n);

    Lx = lap(k, m, dx);
    Ly = lap(k, n, dy);

    Ix = speye((m+2), (m+2));
    Iy = speye((n+2), (n+2));

    XI = diag(xgrid);
    YI = diag(ygrid);

    closeFieldX1D = ((-r*xgrid*IFCx*Gx) - (omega11*omega11/2 * XI*XI * Lx) + r*Ix);

    closeFieldX2D = sparse(zeros((m+2)*(n+2)));

    closeFieldX2D(1:size(closeFieldX1D,1),1:size(closeFieldX1D,2)) = closeFieldX1D;


    closeFieldY1D = ((-r*ygrid*IFCy*Gy) - (omega11*omega11/2 * YI*YI * Ly) + r*Iy);

    tempCloseFieldY2D = sparse(zeros(n+2, (m+2)*(n+2)));

    for i = 0: (n+2)-1
        tempCloseFieldY2D(:,(i*(m+2))+1) = closeFieldY1D(:, i+1);
    end

    closeFieldY2D = sparse(zeros((m+2)*(n+2)));

    for i = 0: (m+2)-1
        closeFieldY2D((i*(n+2))+1,:) = tempCloseFieldY2D(i+1, :);
    end

    closeFieldA = closeFieldX2D + closeFieldY2D;


end

function plotBlackScholes(Fvec, X, Y, m, n, T, t, strike)
    surf(X, Y, reshape(Fvec, m+2, n+2))
    title(['2D Black-Scholes \newlineTime = ' num2str(T-t, '%1.4f')])
    xlabel('x')
    ylabel('y')
    zlabel('F')
    colorbar
    caxis([-0.01 3*strike/5])
    % axis([0 5*strike/3 0 5*strike/3 -0.01 3*strike/5])  % Examining Boundary Up to 5*strike/3 as Done in Paper
    % caxis([-0.05, (b+d-strike)/2])                    % Uncomment for Graph of All of U
    % axis([a b c d -0.05 (b+d-strike)/2])
    drawnow
end
