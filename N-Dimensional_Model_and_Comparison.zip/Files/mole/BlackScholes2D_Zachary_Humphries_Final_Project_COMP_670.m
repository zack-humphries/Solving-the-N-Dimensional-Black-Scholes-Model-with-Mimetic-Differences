%% 2D Black-Scholes PDE
% Zachary Humphries
% COMP 670 - Dr. Miguel Dummet
% Fall 2022

clc
clear
close all

% addpath('.../mole_MATLAB')
addpath('C:\Users\14048\Desktop\SDSU\Fall2023\Research\mole\mole_MATLAB')

%% Spatial discretization

global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r dirichlet_2D dirichlet_x dirichlet_y

strike = 1;                                 % Strike Price

T = 1;                                      % Simulation time

k = 4;                                      % Order of accuracy

a = 0;                                      % Minimum Value of Option for Asset X (must be zero)
b = round(10*strike);                       % Maximum Value of Option for Asset X (Recommended between 8*strike and 12*strike)
c = 0;                                      % Minimum Value of Option for Asset Y (must be zero)
d = b;                                      % Maximum Value of Option for Asset X

m = max(4* round(10*strike), 2*k+1);        % 2*k+1 = Minimum number of cells to attain the desired accuracy
n = m;                                      % Number of cells along the y-axis

dx = (b-a)/m;                               % Step length along the x-axis
dy = (d-c)/n;                               % Step length along the y-axis

dt = min(dx^2/(6), 0.001);                  % Von Neumann stability criterion for explicit scheme dx^2/(4*alpha)

omega11 = 0.3;                              % Omega_xx = Omega_yy of the volatility correlation matrix
omega12 = 0.05;                             % Omega_xy = Omega_yx of the volatility correlation matrix
r = 0.1;                                    % Risk free interest rate

%% Setting Up Vectors of F, X, and Y

xgrid = [a a+dx/2 : dx : b-dx/2 b];
ygrid = [c c+dy/2 : dy : d-dy/2 d];

[X, Y] = meshgrid(xgrid, ygrid);

F = max(((X+Y)/2)-strike, 0);

Fvec = reshape(F, (m+2)*(n+2), 1);
Xvec = diag(reshape(X, 1, (m+2)*(m+2)));
Yvec = diag(reshape(Y, 1, (n+2)*(n+2)));

%% Dirichlet BC

dirichlet_2D = robinBC2D(k,m,dx,n,dy,1,0);
dirichlet_x = robinBC(k,m,dx,1,0);
dirichlet_y = robinBC(k,n,dy,1,0);


%% Setting Up Fx and Fy

FG = grad2D(k, m, dx, n, dy);

Fx1 = FG(1:(length(FG)/2), :);                          % Split Up Gradient Matrix (Gx)
Fy1 = FG((length(FG)/2+1): end, :);                     % Split Up Gradient Matrix (Gy)

interpG = interpolFacesToCentersG2D(k, m, n);
[interpGRows, interpGColumns] = size(interpG);

interp_kron_x = interpG(:, 1:(interpGColumns/2));      % Split Up Interpolation Matrix (Igx)
interp_kron_y = interpG(:, (interpGColumns/2)+1:end);  % Split Up Interpolation Matrix (Igy)

Fx = (interp_kron_x * Fx1);
Fy = (interp_kron_y * Fy1);

first = (-r *Xvec*Fx) -(r *Yvec*Fy);

%% Setting Up Fxx and Fyy

grad_2D = grad2D(k, m, dx, n, dy);

grad_x = grad_2D(1:(length(grad_2D)/2), :);             % Split Up Gradient Matrix (Gx)
grad_y = grad_2D((length(grad_2D)/2+1): end, :);        % Split Up Gradient Matrix (Gy)

D_2D = div2D(k, m, dx, n, dy);
div_x = D_2D(:, 1:(length(D_2D)/2));                    % Split Up Divergence Matrix (Dx)
div_y = D_2D(:, (length(D_2D)/2+1): end);               % Split Up Divergence Matrix (Dy)

Fxx = (div_x*grad_x);
Fyy = (div_y*grad_y);

second = - (1/2 * omega11^2 * Xvec*Xvec * Fxx) - (1/2* omega11^2 * Yvec*Yvec* Fyy);

%% Setting Up Fxy

FG = grad2D(k, m, dx, n, dy);

D_2D = div2D(k, m, dx, n, dy);

div_x = D_2D(:, 1:(length(D_2D)/2));                    % Split Up Divergence Matrix (Dx)
div_y = D_2D(:, (length(D_2D)/2+1): end);               % Split Up Divergence Matrix (Dy)

interp_d_2D = interpolCentersToNodes2D(k,m,n);

interp_2d_kron_x = interp_d_2D(1:(length(interp_d_2D)/2), :);       % Split Up Interpolation Matrix (Idx)
interp_2d_kron_y = interp_d_2D((length(interp_d_2D)/2+1): end, :);  % Split Up Interpolation Matrix (Idy)

Fyx = div_y * (interp_2d_kron_y * Fx);                  % [Dy * Idy * Igx * Gx]
Fxy = div_x * (interp_2d_kron_x * Fy);                  % [Dx * Idx * Igy * Gy]

third = - (omega12^2 * Xvec * Yvec * Fxy);
third1 = - (omega12^2 * Xvec * Yvec * Fyx);

third2 = reshape(min(third*Fvec, third1*Fvec), m+2, n+2);

third2(m+1, n+1) = (third2(m, n+1) + third2(m+1, n) + third2(m, n))/3;
third2 = reshape(third2, (m+2) * (n+2) , 1);

%% Setting Up Final F

fourth = r* (speye((m+2)*(n+2), (m+2)*(n+2))- dirichlet_2D);
fourth(1,1) = 0;
fourth(end,end) = 0;

%% Combining All Together

Ft1 = (((first + second + third + fourth) + dirichlet_2D))*Fvec;

Ft_reshape = reshape(Ft1,(m+2),(n+2));

Ft_reshape1 = Ft_reshape;

%% Setting Up Initial Values and Dirichlet Boundary Conditions

ICV = max(((X+Y)/2)-strike, 0);

upperx = ((b+ygrid)/2);
uppery = ((xgrid+d)/2);

ICV(end,:) = upperx;
ICV(:,end) = uppery;
ICV(1,1) = 0;

U = reshape(ICV, (m+2)*(n+2), 1);

%% Close-Field Boundary Conditions

Gx_1D = grad(k, m, dx);
Gy_1D = grad(k, n, dy);

FXgrid = max(((xgrid')/2)-strike,0);
FYgrid = max(((ygrid')/2)-strike,0);

FXG = Gx_1D;
FYG = Gy_1D;

Igx = interpGMat(k, m);
Igy = interpGMat(k, n);

Fx_1D = Igx*FXG;
Fy_1D = Igy*FYG;

Lx_1D = lap(k, m, dx);
Ly_1D = lap(k, n, dy);

Fxx_1D = Lx_1D;
Fyy_1D = Ly_1D;

xmatrix = diag(xgrid');
ymatrix = diag(ygrid');

xaxis = ((-r.*xmatrix*Fx_1D) - (1/2 * omega11^2 * xmatrix*xmatrix* Fxx_1D) + r*speye(m+2,m+2));
yaxis = ((-r.*ymatrix*Fy_1D) - (1/2 * omega11^2 * ymatrix*ymatrix *Fyy_1D) + r*speye(n+2,n+2));


Ft_reshape1(1,:) = xaxis*FXgrid;
Ft_reshape1(:,1) = yaxis*FYgrid;

Ft = reshape(Ft_reshape1, (m+2)*(n+2), 1);

U_minus = U;
U = U_minus + dt*Ft;                            % First-Order Accurate (in Time) Initial Time Step
U = reshape(U, m+2, n+2);

uppery = ((b+ygrid)/2)-(strike*exp(-r*(T-0)));  % Updating Far-Field Boundary Conditions
upperx = ((xgrid+d)/2)-(strike*exp(-r*(T-0)));  % Updating Far-Field Boundary Conditions
U(end,:) = upperx;
U(:,end) = uppery;
U = reshape(U, (m+2)*(n+2), 1);

%% Time integration loop
count = 1;
len = length(dt : dt : T-dt );
for t = dt : dt : T-dt 
    fprintf("%f ",count)
    fprintf("%f \n",len)
    count = count+1;

    Ft1 = (((first + second + third + fourth) + dirichlet_2D))*U;

    Ft = Ft_maker(Ft1, U);
    
    U_plus = (((dt-1)/dt).*U +(1/(2*dt)).*U_minus + dt*Ft)./(1-(1/(2*dt)));     % Second-Order Accurate (in Time) Initial Time Step

    U_plus = reshape(U_plus, m+2, n+2);

    uppery = ((b+ygrid)/2)-(strike*exp(-r*(T-t)));  % Updating Boundary Conditions
    upperx = ((xgrid+d)/2)-(strike*exp(-r*(T-t)));  % Updating Boundary Conditions
    U_plus(end,:) = upperx;
    U_plus(:,end) = uppery;
    
    U_minus = U;
    U = reshape(U_plus, (m+2)*(n+2), 1);

end

U_graph = max(U, 0);                                % Option Value doesn't go below zero at t=0
surf(X, Y, reshape(U_graph, m+2, n+2))
title(['2D Black-Scholes \newlineTime = ' num2str(T-t-dt, '%1.4f')])
xlabel('x')
ylabel('y')
zlabel('F')
colorbar
caxis([-0.01 3*strike/5])
axis([0 5*strike/3 0 5*strike/3 -0.01 3*strike/5])  % Examining Boundary Up to 5*strike/3 as Done in Paper
% caxis([-0.05, (b+d-strike)/2])                    % Uncomment for Graph of All of U
% axis([a b c d -0.05 (b+d-strike)/2])
drawnow


function result = first_maker()
    global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r 
    
    FG = grad2D(k, m, dx, n, dy);
   
    
    Fx1 = FG(1:(length(FG)/2), :);
    Fy1 = FG((length(FG)/2+1): end, :);
    
    interpG = interpolNodesToCenters2D(k, m, n);
    
    interp_kron_x = interpG(:, 1:(length(interpG)/2));
    interp_kron_y = interpG(:, (length(interpG)/2)+1:end);
    
    Fx = interp_kron_x * Fx1;
    Fy = interp_kron_y * Fy1;
    
    result = (-r *Xvec *Fx) -(r *Yvec *Fy);

end

function result = second_maker()
    global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r 

    grad_2D = grad2D(k, m, dx, n, dy);

    grad_x = grad_2D(1:(length(grad_2D)/2), :);
    grad_y = grad_2D((length(grad_2D)/2+1): end, :);
    
    D_2D = div2D(k, m, dx, n, dy);
    div_x = D_2D(:, 1:(length(D_2D)/2));
    div_y = D_2D(:, (length(D_2D)/2+1): end);
    
    Fxx = div_x*(grad_x);
    Fyy = div_y*(grad_y);
    
    result = - (1/2 * omega11^2 * Xvec*Xvec * Fxx) - (1/2* omega11^2 * Yvec*Yvec* Fyy);
end

function result = third_maker(U)
    global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r 

    FG = grad2D(k, m, dx, n, dy);
    
    Fx1 = FG(1:(length(FG)/2), :);
    Fy1 = FG((length(FG)/2+1): end, :);

    interpG = interpolCentersToNodes2D(k, m, n);
    
    interp_kron_x = interpG(:, 1:(length(interpG)/2));
    interp_kron_y = interpG(:, (length(interpG)/2)+1:end);
    
    Fx = interp_kron_x * Fx1;
    Fy = interp_kron_y * Fy1;
    
    D_2D = div2D(k, m, dx, n, dy);
    
    div_x = D_2D(:, 1:(length(D_2D)/2));
    div_y = D_2D(:, (length(D_2D)/2+1): end);
    
    interp_d_2D = interpolCentersToNodes2D(k,m,n);
    
    interp_2d_kron_x = interp_d_2D(1:(length(interp_d_2D)/2), :);
    interp_2d_kron_y = interp_d_2D((length(interp_d_2D)/2+1): end, :);
    
    Fyx = div_y * interp_2d_kron_y * Fx;
    Fxy = div_x * interp_2d_kron_x * Fy;
    
    
    third = - (r * omega12^2 * Xvec * Yvec * Fxy);
    third1 = - (r * omega12^2 * Xvec * Yvec * Fyx);

    result = third;
end

function result = fourth_maker()
    global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r dirichlet_2D

    result = r* (speye((m+2)*(n+2), (m+2)*(n+2))-dirichlet_2D);
end

function result = Ft_maker(Ft1, U)

    global k m n dx dy dt xgrid ygrid Xvec Yvec omega11 omega12 r dirichlet_x dirichlet_y
    
    Ft_reshape = reshape(Ft1,(m+2),(n+2));
    Ft_reshape1 = Ft_reshape;

    U_reshaped = reshape(U, m+2, n+2);

    FXgrid = U_reshaped(1,:)';
    FYgrid = U_reshaped(:,1);

    Gx_1D = grad(k, m, dx);
    Gy_1D = grad(k, n, dy);
    
    FXG = Gx_1D;
    FYG = Gy_1D;
    
    Igx = interpolNodesToCenters2D(k, m);
    Igy = interpolNodesToCenters2D(k, n);
    
    Fx_1D = Igx*FXG;
    Fy_1D = Igy*FYG;
    
    Lx_1D = lap(k, m, dx);
    Ly_1D = lap(k, n, dy);
    
    Fxx_1D = Lx_1D;
    Fyy_1D = Ly_1D;
    
    xmatrix = diag(xgrid');
    ymatrix = diag(ygrid');

    xaxis = ((-r.*xmatrix*Fx_1D) - (1/2 * omega11^2 * xmatrix*xmatrix* Fxx_1D) + r*speye(m+2,m+2)) + dirichlet_x;
    yaxis = ((-r.*ymatrix*Fy_1D) - (1/2 * omega11^2 * ymatrix*ymatrix *Fyy_1D) + r*speye(n+2,n+2)) + dirichlet_y;
    
    Ft_reshape1(1,:) = xaxis*FXgrid;
    Ft_reshape1(:,1) = yaxis*FYgrid;
    
    result = reshape(Ft_reshape1, (m+2)*(n+2), 1);
end

