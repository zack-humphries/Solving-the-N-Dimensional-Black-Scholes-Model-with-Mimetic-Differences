%% 2D Black-Scholes PDE
% Zachary Humphries
% COMP 797 - Dr. Miguel Dumett
% Fall 2023

clear all;
close all;
clc;

addpath('C:\Users\14048\Desktop\SDSU\Fall2023\Research\EurCall Code')


[Fsol, X, Y] = BlackScholes2DMD_Implicit_Order2_fun();

[u, xx, yy] = RBFPUM_EurCall2D_HalfStep_fun();

figure
plotBlackScholes(Fsol(:,end), X, Y, 0, 1)
figure
plotBlackScholes(u(:,end), xx, yy, 0, 1)


figure
plotBlackScholes(Fsol(:,end)-u(:,end), X, Y, 0, 1)
% hold on
% plotBlackScholes(u(:,end), xx, yy, 0)

function plotBlackScholes(Fvec, X, Y, t, strike)
    
    surf(X, Y, reshape(Fvec, length(X), length(Y)))
    title(['2D Black-Scholes \newlineTime = ' num2str(t, '%1.4f')])
    xlabel('x')
    ylabel('y')
    zlabel('F')
    colorbar%('Ticks',min([a b]):max([c d]))
    %axis([a b c d]);
    axis([0 (5*strike/3) 0 (5*strike/3)])
%    caxis([0 3/2 *strike])
    drawnow
end

% strike = 1;
% surf(X, Y, reshape(Fsol(:,end)-u(:,end), length(X), length(Y)))
% title(['2D Black-Scholes \newlineTime = ' num2str(0, '%1.4f')])
% xlabel('x')
% ylabel('y')
% zlabel('F')
% colorbar%('Ticks',min([a b]):max([c d]))
% %   axis([a b c d]);
% axis([(strike/3) (5*strike/3) (strike/3) (5*strike/3) 0 1/3 *strike])
% %    caxis([0 3/2 *strike])
% drawnow