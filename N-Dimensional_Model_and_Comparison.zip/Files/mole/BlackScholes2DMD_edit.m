%% 2D Black-Scholes PDE
% Zachary Humphries
% COMP 797 - Dr. Miguel Dumett
% Fall 2023

clear all;
close all;
clc;

addpath('C:\Users\14048\Desktop\SDSU\Fall2023\Research\mole\mole_MATLAB')


%% parameters depend on strike price value
T = 1;
strike = 1;                                 % Strike Price
omega = [0.3 0.05; 0.05 0.3];
r = 0.03;                                    % Risk free interest rate

k = 2;                                      % Order of accuracy

a = 0;                                      % Minimum Value of Option for Asset X (must be zero)
b = round(10*strike);                       % Maximum Value of Option for Asset X (Recommended between 8*strike and 12*strike)
c = 0;                                      % Minimum Value of Option for Asset Y (must be zero)
d = b;                                      % Maximum Value of Option for Asset X

m = 40; %2*k+1; % max(4* round(10*strike), 2*k+1);        % 2*k+1 = Minimum number of cells to attain the desired accuracy
n = m;                                      % Number of cells along the y-axis

dx = (b-a)/m;                               % Step length along the x-axis
dy = (d-c)/n;                               % Step length along the y-axis

dt = 0.05*((1/dx)^2 + (1/dy)^2)^(-1); % min(dx^2/4, 0.001);                  % Von Neumann stability criterion for explicit scheme dx^2/(4*alpha)

%% mesh
xgrid = [a a+dx/2 : dx : b-dx/2 b];
ygrid = [c c+dy/2 : dy : d-dy/2 d];
[X, Y] = meshgrid(xgrid, ygrid);

%% initial condition
F = max(((X+Y)/2)-strike, 0); 

Fvec = reshape(F', (m+2)*(n+2), 1);
Xvec = reshape(X', (m+2)*(m+2), 1);
Yvec = reshape(Y', (n+2)*(n+2), 1);

%% operator matrix

small_I = speye((m+2)*(m+2), (n+2)*(n+2));
I = speye((m+2)*(m+2)+(n+2)*(n+2), (m+2)*(m+2)+(n+2)*(n+2));

XI = spdiags(Xvec, 0, (m+2)*(m+2), (m+2)*(m+2));
YI = spdiags(Yvec, 0, (n+2)*(n+2), (n+2)*(n+2));

XYI = spdiags([Xvec; Yvec], 0, (m+2)*(m+2)+(n+2)*(n+2), (m+2)*(m+2)+(n+2)*(n+2));

XY = [XI,YI];

O = [omega(1,1)*small_I, omega(1,2)*small_I; omega(2,1)*small_I, omega(2,2)*small_I]; % MD

%% Setting Up Gradient and Divergence Matricies

G = grad2D(k, m, dx, n, dy);
D = div2D(k, m, dx, n, dy);

%% Setting Up Interpolation Matrices

IFC = interpolFacesToCentersG2D(k, m, n);
ICF = interpolCentersToFacesD2D(k, m, n);

%% Combine for Black-Scholes Matrix

A = -(r*XY*IFC*G) - 0.5*(D*ICF*XYI*O*XYI*IFC*G) + r*small_I;

%% Plot Initial Conditions
plotBlackScholes(Fvec, X, Y, m, n, T, a, b, c, d);

%% auxiliary variables
len = length(0 : dt : T);
Fsol = zeros(numel(Fvec), len); % to store solutions
Fsol(:,1) = Fvec;

Faux = Fvec; % to jump start time discretization

%% Forward Euler
count = 1;
for t = dt : dt : T

    time = T-t;

    Faux = (small_I - dt*A)*Fsol(:,count);
    [closeFieldX,closeFieldY] = closeFieldBC(k, m, n, dx, dy, xgrid, ygrid, r, omega, Faux, dt);
    [farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, strike, r, T, time);

    %% Adjust Faux to Account for Close-Field and FarField Boundary Conditions
    Faux(1:m+2:end) = closeFieldY;
    Faux(1:m+2) = closeFieldX;
    Faux(m+2:m+2:end) = farFieldY;
    Faux(end-m-1:end) = farFieldX;
    Faux(1,1) = 0;

    plotBlackScholes(Faux, X, Y, m, n, time, a, b, c, d);

    count = count+1;
    Fsol(:,count) = Faux;

end

plotBlackScholes(Faux, X, Y, m, n, time, a, b, c, d);


%% Far-Field Coundary Condition

function [farFieldX, farFieldY] = farFieldBC(b, d, xgrid, ygrid, K, r, T, time)

    farFieldX = (b + ygrid)/2 - K*exp(-r*(T-time));
    farFieldY = (d + xgrid)/2 - K*exp(-r*(T-time));    

end


%% Close-Field Boundary Condition

function [closeFieldX, closeFieldY] = ...
    closeFieldBC(k, m, n, dx, dy, xgrid, ygrid, r, omega, Faux, dt)

    Gx = grad(k, m, dx);
    Gy = grad(k, n, dy);

    IFCx = interpolFacesToCentersG1D(k,m);
    IFCy = interpolFacesToCentersG1D(k,n);

    Lx = lap(k, m, dx);
    Ly = lap(k, n, dy);

    Ix = speye((m+2), (m+2));
    Iy = speye((n+2), (n+2));

    XI = diag(xgrid);
    YI = diag(ygrid);

    Mx = ((-r*XI*IFCx*Gx) - (omega(1,1)*omega(1,1)/2 * XI*XI * Lx) + r*Ix);
    closeFieldX = (Ix-dt*Mx)*Faux(1:m+2:end);

    My = ((-r*YI*IFCy*Gy) - (omega(1,1)*omega(2,2)/2 * YI*YI * Ly) + r*Iy);
    closeFieldY = (Ix-dt*My)*Faux(1:m+2);
end

function plotBlackScholes(Fvec, X, Y, m, n, t, a, b, c, d)
    surf(X, Y, reshape(Fvec, m+2, n+2))
    title(['2D Black-Scholes \newlineTime = ' num2str(t, '%1.4f')])
    xlabel('x')
    ylabel('y')
    zlabel('F')
    colorbar
    axis([a b c d]);
    drawnow
end

