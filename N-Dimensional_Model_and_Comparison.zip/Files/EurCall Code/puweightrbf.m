% Define partition of unity weights using Shepard's method

%  (C) Victor Shcherbakov 2015

function [w,wx,wy,wxx,wxy,wyx,wyy] = puweightrbf(xc,Np,cntr,R,indlocpts,box)

[s,sx,sy,sxx,sxy,syx,syy] = deal(zeros(size(xc,1),1));
for i = 1:Np
    [phi,phix,phiy,phixx,phixy,phiyx,phiyy] = weightrbf(xc,box(i).indlocpts,box(i).midpt,box(i).R);
    s = s + phi;
    sx = sx + phix;
    sy = sy + phiy;
    sxx = sxx + phixx;
    sxy = sxy + phixy;
    syx = syx + phiyx;
    syy = syy + phiyy;
end


[W,Wx,Wy,Wxx,Wxy,Wyx,Wyy] = deal(zeros(size(xc,1),1));
[phi,phix,phiy,phixx,phixy,phiyx,phiyy] = weightrbf(xc,indlocpts,cntr,R);
W =  phi./s;
Wx = phix./s - phi.*sx./s.^2;
Wy = phiy./s - phi.*sy./s.^2;
Wxx = -2*phix.*sx./s.^2 + phixx./s + phi.*(2*sx.^2./s.^3 - sxx./s.^2);
Wxy = phixy./s - phix.*sy./s.^2 - phiy.*sx./s.^2 - phi.*sxy./s.^2 + 2*phi.*sx.*sy./s.^3;
Wyx = phiyx./s - phiy.*sx./s.^2 - phix.*sy./s.^2 - phi.*syx./s.^2 + 2*phi.*sy.*sx./s.^3;
Wyy = -2*phiy.*sy./s.^2 + phiyy./s + phi.*(2*sy.^2./s.^3 - syy./s.^2);

w = W(indlocpts);
wx = Wx(indlocpts);
wy = Wy(indlocpts);
wxx = Wxx(indlocpts);
wxy = Wxy(indlocpts);
wyx = Wyx(indlocpts);
wyy = Wyy(indlocpts);
end

