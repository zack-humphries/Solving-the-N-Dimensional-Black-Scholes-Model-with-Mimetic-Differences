% Define Wendland's function and its derivatives

%  (C) Victor Shcherbakov 2015

function [phi,phix,phiy,phixx,phixy,phiyx,phiyy] = weightrbf(xc,ind,cntr,R)

[phi,phix,phiy,phixx,phixy,phiyx,phiyy] = deal(zeros(size(xc,1),1));

ep = 1/R;
dx = xc(:,1)-cntr(1);
dy = xc(:,2)-cntr(2);
r = sqrt(dx.^2 + dy.^2);

phi = (4*ep*r+1).*(1-ep*r).^4;
phix = -20*ep^2*dx.*(1-ep*r).^3;
phiy = -20*ep^2*dy.*(1-ep*r).^3;
phixx = -20*ep*(1-ep*r).^2 + 60*ep^5*dx.^2.*r - 120*ep^4*dx.^2 + 60*ep^3*dx.^2./r;
phixy = 60*ep^5*dx.*dy.*r - 120*ep^4*dx.*dy + 60*ep^3*dx.*dy./r;
phiyx = 60*ep^5*dy.*dx.*r - 120*ep^4*dy.*dx + 60*ep^3*dy.*dx./r;
phiyy = -20*ep*(1-ep*r).^2 + 60*ep^5*dy.^2.*r - 120*ep^4*dy.^2 + 60*ep^3*dy.^2./r;


fullind = 1:1:length(xc);
nonind = setdiff(fullind,ind);
phi(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phix(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phiy(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phixx(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phixy(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phiyx(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;
phiyy(find((xc(:,1) - cntr(1)).^2 + (xc(:,2) - cntr(2)).^2 >= R^2))=0;

end

















