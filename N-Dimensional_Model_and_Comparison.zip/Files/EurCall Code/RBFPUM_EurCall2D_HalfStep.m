% Radial Basis Function Partition of Unity Method 
% for pricing European call option on two assets

clear all
close all

%% Parameters

K = 1; % Strike price
r = 0.05; % Risk free interest rate
sigma=[0.3 0.05; 0.05 0.3]; % Volatility matrix
s=sigma.*sigma; 
e = 0.00001; % Penalty parameter 
C = r*K;


N = (4*2)^2 +1; % Space nodes
x_min = 0; % Min value of 1st asset
x_max = round(10*K); % Max value of 1st asset
y_min = 0; % Min value of 2nd asset
y_max = x_max; % Max value of 2nd asset
h = (x_max-x_min)/(N); % Space step length
dx = h;
dy = h;


T = 1; % Time of maturity
dt = 0.05*((1/h)^2 + (1/h)^2)^(-1); % Time step length

TT = round(T/dt); % Time steps

ep = 1; % RBF shape parameter

np = 6; % Number of partitions per dimension


%% Grid

% Uniform grid
xgrid = [x_min x_min+dx/2 : dx : x_max-dx/2 x_max]';
ygrid = [y_min y_min+dx/2 : dy : y_max-dy/2 y_max]'; 
[xx,yy] = meshgrid(xgrid',ygrid');
xc = [xx(:) yy(:)];

% Boundaries
b0 = find(xc(:,1)==0 & xc(:,2)==0); % Near-field
bx = find(xc(:,1)==x_max); % Far-field x-direction
by = find(xc(:,2)==x_max); % Far-field y-direction

% Vectors xc(:,1) and xc(:,2) in matrix form
N = N+2;
X = spdiags(xc(:,1),0,N^2,N^2);
Y = spdiags(xc(:,2),0,N^2,N^2);

F = max((xc(:,1)+xc(:,2))/2-K,0); % Payoff
q = (xc(:,1)+xc(:,2))/2-K; % Barrier function


%% Partition of unity

% Divide [x_min,x_max]x[y_min,y_max] into np x np overlapping circular
% partitions

% We will store partition centers, indeces, radii, 
% nodes coordinates and so on in structure ibox  

rp = 0.3; % Overlap parameter

% Create and organize centers for partitions
xz = linspace(x_min,x_max,np+1); 
dimen = min(diff(xz));
xz = xz(1:end-1) + 0.5*dimen; 
[xm,ym] = meshgrid(xz,xz); % Coordinates of the centers
xm = [xm(:) ym(:)];

Np = length(xm); % Total numer of partitions (in 2D = np^2)
xm = num2cell(xm,2);
[ibox(1:Np).midpt] = deal(xm{:}); 
clear xz ym ind;

R = (1+rp)*hypot(0.5*dimen,0.5*dimen); % Radius 
[ibox.R] = deal(R);

[ibox.indlocpts] = deal([]); % Location of nodes


% Organize RBF nodes using structure 
% Basically find which nodes fall in which partitions and store this 
% information in the structure
xc = num2cell(xc,2);
Nc = length(xc(:,1));
[data(1:Nc).ctr] = deal(xc{:}); 
[data.circind] = deal([]);
xc = cat(1,xc{:});

xm = cat(1,xm{:});
for i=1:Np
    flagin = hypot(xm(i,1)-xc(:,1),xm(i,2)-xc(:,2)) < ibox(i).R;
    ibox(i).indlocpts = find(flagin);       
    for j=1:length(ibox(i).indlocpts)
        data(ibox(i).indlocpts(j)).circind = [data(ibox(i).indlocpts(j)).circind i];
    end
end

% Define the partition of unity weight using Shepard's method
for i=1:Np
    [puww,puwwx,puwwy,puwwxx,puwwxy,puwwyx,puwwyy] = puweightrbf(xc,Np,ibox(i).midpt,ibox(i).R,ibox(i).indlocpts,ibox);
    ibox(i).w = puww; 
    ibox(i).wx = puwwx; 
    ibox(i).wy = puwwy; 
    ibox(i).wxx = puwwxx;
    ibox(i).wxy = puwwxy;
    ibox(i).wyx = puwwyx;
    ibox(i).wyy = puwwyy; 
end

%% RBF matrices

L = spalloc(N^2,N^2,N^4);
for i=1:Np
    
    % Build local RBF matrices 
    ind = ibox(i).indlocpts;
    rc = xcdist(xc(ind,:),xc(ind,:),1);
    A0  = RBFmat('mq',ep,rc,'0');
    Ax  = RBFmat('mq',ep,rc,'1',1);
    Ay  = RBFmat('mq',ep,rc,'1',2);
    Axx = RBFmat('mq',ep,rc,'2',1);
    Axy = RBFmat('mq',ep,rc,'m2',[1,2]);
    Ayy = RBFmat('mq',ep,rc,'2',2);

    % Construct derivative matrices
    D0 = diag(ibox(i).w)*A0; 
    Dx = diag(ibox(i).w)*Ax + diag(ibox(i).wx)*A0;
    Dy = diag(ibox(i).w)*Ay + diag(ibox(i).wy)*A0;

    Dxx = diag(ibox(i).w)*Axx + 2*diag(ibox(i).wx)*Ax + diag(ibox(i).wxx)*A0; 
    Dyy = diag(ibox(i).w)*Ayy + 2*diag(ibox(i).wy)*Ay + ...
          diag(ibox(i).wyy)*A0;

    Dxy = diag(ibox(i).w)*Axy + diag(ibox(i).wx)*Ay + ...
          diag(ibox(i).wy)*Ax + diag(ibox(i).wxy)*A0;
    Dyx = diag(ibox(i).w)*Axy + diag(ibox(i).wy)*Ax + ...
          diag(ibox(i).wx)*Ay + diag(ibox(i).wyx)*A0;

    % Local spatial operator
    ibox(i).B = -((r)*X(ind,ind)*Dx + (r)*Y(ind,ind)*Dy ...
        + 0.5*s(1,1)*X(ind,ind).^2*Dxx ...
        + 0.5*s(1,2)*X(ind,ind)*Y(ind,ind)*Dxy ...
        + 0.5*s(2,1)*X(ind,ind)*Y(ind,ind)*Dyx ...
        + 0.5*s(2,2)*Y(ind,ind).^2*Dyy - r*D0);
    ibox(i).B = ibox(i).B/A0;

    % Add them into a global matrix
    L(ind,ind) = L(ind,ind) + ibox(i).B;
    
end

% Needed to have right boundary conditions
L(b0,:) = 0;
L(bx,:) = 0;
L(by,:) = 0;


%% Solve the system

% We use BDF-2 scheme for time marching 
% At the first step solve by implicit Euler

u = zeros(size(xc,1),TT); % Allocate for solution

u(:,1) = F; % Initial condition

I = speye(size(L));
R = I + dt*L; % Implicit Euler martix 
[Lr,Ur] = lu(R); % LU factorization

rhs = u(:,1); % Define right hand side

% Assign boundary conditions
rhs(bx) = 3/2*farFieldBC(x_max, xgrid, K, r, (TT-1)*dt);
rhs(by) = 3/2*farFieldBC(x_max, xgrid, K, r, (TT-1)*dt);

% Solve
u(:,2) = Ur\(Lr\rhs);

% Move on to the BDF-2 scheme

R = (3/2)*I + dt*L; % BDF-2 matrix
[Lr,Ur] = lu(R);
clear R L I

tic
for n = 3:TT
    
    % Define right hand side
    rhs = 2*u(:,n-1) - u(:,n-2)/2; 
    
    % Assign boundary conditions
    % rhs(b0) = 3/2*F(b0);
    rhs(bx) = 3/2*farFieldBC(x_max, xgrid, K, r, (TT-n+1)*dt);
    rhs(by) = 3/2*farFieldBC(x_max, xgrid, K, r, (TT-n+1)*dt);

    % Solve
    u(:,n) = Ur\(Lr\(rhs));

    % plotBlackScholes(u(:,n), xx, yy, (TT-n)*dt, x_min, x_max, y_min, y_max, K)

    
end
cpuTime = toc


plotBlackScholes(u(:,end), xx, yy, 0, x_min, x_max, y_min, y_max, K)

function plotBlackScholes(Fvec, X, Y, t, a, b, c, d, strike)
    
    surf(X, Y, reshape(Fvec, length(X), length(Y)))
    title(['2D Black-Scholes \newlineTime = ' num2str(t, '%1.4f')])
    xlabel('x')
    ylabel('y')
    zlabel('F')
    colorbar
    axis([a b c d]);
%    axis([0 (5*strike/3) 0 (5*strike/3) 0 (5/3)*strike])
%    caxis([0 3/2 *strike])
    drawnow
end

function [farField] = farFieldBC(b, xgrid, strike, r, time)

    farField = (b + xgrid)/2 - strike*exp(-r*(time));

end
