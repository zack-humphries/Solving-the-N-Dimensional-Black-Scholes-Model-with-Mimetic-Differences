% Radial Basis Function Partition of Unity Method 
% for pricing American call option on one assets

%  (C) Victor Shcherbakov 2015

clear all
close all

%% Parameters

N = 40; % Space nodes
x_min = 0; % Min value of the asset
x_max = 4; % Max value of the asset
h = x_max/(N-1); % Space step length

TT = 2800; % Time steps
T = 1; % Time of maturity
dt = T/TT; % Time step length

K = 1; % Strike price
r = 0.1; % Risk free interest rate
s = 0.3; % Volatility
d = 0.05; % Dividend
e = 0.00007; % Penalty parameter 
C = r*K;

ep = 1.7; % RBF shape parameter

np = 4; % Number of partitions per dimension


%% Grid

% Uniform grid
xc = (x_min:h:x_max)';

% vectors xc(:,1) and xc(:,2) in matrix form
X = spdiags(xc,0,N,N);

% Boundaries
b0 = find(xc==0); % Near-field
bx = find(xc==x_max); % Far-field 

F = max(xc-K,0); % Payoff
q = xc-K; % Barrier function


%% Partition of unity

% Divide [x_min,x_max] into np overlapping circular partitions

% We will store partition centers, indeces, radii, 
% nodes coordinates and so on in structure ibox

% Create and organize centers for partitions
x = linspace(x_min,x_max,np+1); 
dimen = min(diff(x));
x = x(1:end-1) + 0.5*dimen; 
xm = num2cell(x);
[ibox(1:np).midpt] = deal(xm{:}); 
clear x ym ind;

rp = 0.1; % Overlap
R = hypot(0.5*dimen,0.5*dimen) + rp; % Radius
[ibox.R] = deal(R);

[ibox.indlocpts] = deal([]); % Location of nodes

% Organize RBF nodes using structure
% Basically find which nodes fall in which partitions and store this 
% information in the structure
xc = num2cell(xc);
[data(1:N).ctr] = deal(xc{:}); 
[data.circind] = deal([]);
xc = cat(1,xc{:});

xm = cat(1,xm{:});
for i=1:np
    flagin = abs(xm(i)-xc(:)) < ibox(i).R;
    ibox(i).indlocpts = find(flagin);       
    for j=1:length(ibox(i).indlocpts)
        data(ibox(i).indlocpts(j)).circind = [data(ibox(i).indlocpts(j)).circind i];
    end
end

% Define the partition of unity weight using Shepard's method
for i=1:np
    [puww,puwwx,puwwxx] = puweight_1D(xc,np,ibox(i).midpt,ibox(i).R,ibox(i).indlocpts,ibox);
    ibox(i).w = puww; 
    ibox(i).wx = puwwx; 
    ibox(i).wxx = puwwxx;
end


%% Open reference solution (operator splitting finite difference)

fileID = fopen('os1D.txt');
Vos = fscanf(fileID, '%g');
fclose(fileID);

% Define the reference grid
Ne = length(Vos);
he = x_max/(Ne-1);
xeval = (x_min:he:x_max)';

% Check which reference points fall in which partitions
for i = 1:np
    iboxeval(i).indlocpts = find(abs(xm(i)-xeval(:)) < ibox(i).R);
    iboxeval(i).R = ibox(i).R;
    iboxeval(i).midpt = ibox(i).midpt;
end

% Define the partition of unity weghts for the reference points
for i=1:np
    [puwweval,puwwxeval,puwwxxeval] = puweight_1D(xeval,np,iboxeval(i).midpt,iboxeval(i).R,iboxeval(i).indlocpts,iboxeval);
    iboxeval(i).w = puwweval; 
end


%% RBF matrices

B0 = zeros(N);
B1 = zeros(N);
B2 = zeros(N);

M = zeros(N);
E = zeros(Ne,N);

for i = 1:np
    
    % Build local RBF matrices 
    indpts = ibox(i).indlocpts;
    rc = xcdist(xc(indpts),xc(indpts),1);
    A0 = RBFmat('mq',ep,rc,'0',1);
    Ax = RBFmat('mq',ep,rc,'1',1);
    Axx = RBFmat('mq',ep,rc,'2',1);

    % Construct derivative matrices
    B00 = ( dt*r*diag(ibox(i).w)*A0 )/A0;
    B0(indpts,indpts) = B0(indpts,indpts) + B00;

    B11 = ( dt*(r-d)*diag(xc(indpts))*diag(ibox(i).w)*Ax + dt*(r-d)*diag(xc(indpts))*diag(ibox(i).wx)*A0 )/A0; 
    B1(indpts,indpts) = B1(indpts,indpts) + B11;

    B22 = ( dt*s^2*diag(xc(indpts))^2*diag(ibox(i).w)*Axx/2 + dt*s^2*diag(xc(indpts))^2*diag(ibox(i).wx)*Ax + ...
        dt*s^2*diag(xc(indpts))^2*diag(ibox(i).wxx)*A0/2 )/A0; 
    B2(indpts,indpts) = B2(indpts,indpts) + B22;
    
    
    % Construct the evaluation matrix
    M0 = diag(ibox(i).w)*A0;
    M(indpts,indpts) = M(indpts,indpts) + M0;
     
    indeval = iboxeval(i).indlocpts;
    reval = xcdist(xeval(indeval),xc(indpts),1);
    Aeval = RBFmat('mq',ep,reval,'0',1);
    evalind = iboxeval(i).indlocpts;
    E0 = diag(iboxeval(i).w)*Aeval;
    E(evalind,indpts) = E(evalind,indpts) + E0;
    
end


%% Solve the system

% We use BDF-2 scheme for time marching 
% At the first step solve by implicit Euler

u = zeros(N,TT); % Allocate for solution

u(:,1) = F; % Initial condition

% Spatial operator
A = B2 + B1 - B0;
% Needed for right boundary treatment
A(1,:) = 0;
A(end,:) = 0;

R = eye(N) - A; % Implicit Euler matrix


% Mt = R\(eye(N)+dt*r*K/e);
% eg = sort(abs(eig(Mt)));
% plot(eg(2:end-1),'o')

% Define the penalty function
Q = (e*C-e*d*xc)./(u(:,1)+e-q);
Q(b0) = 0;
Q(bx) = 0;

% Solve
u(:,2) = R\(u(:,1)-dt*Q);

% Assign boundary conditions
u(b0,2) = F(b0);
u(bx,2) = F(bx);


% Move on to the BDF-2 scheme

R = 3*eye(N)/2 - A; % BDF-2 matrix

for n = 3:TT
    
    % Define the penalty function
    Q = (e*C-e*d*xc)./(u(:,n-1)+e-q);
    Q(b0) = 0;
    Q(bx) = 0;
    
    % Solve
    u(:,n) = R\(2*u(:,n-1)) - R\(u(:,n-2)/2) - R\(dt*Q);
    
    % Assign boundary conditions
    u(1,n) = F(1);
    u(end,n) = F(end);
end

% Evaluate at the fine grid
lambda = M\u(:,end);
U = E*lambda;

% Check the error
ind = find(1/3<=xeval & xeval<=5/3);
Error = max(abs(Vos(ind)-U(ind)))














