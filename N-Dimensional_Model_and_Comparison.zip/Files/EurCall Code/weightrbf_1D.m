% Define Wendland's function and its derivatives

%  (C) Victor Shcherbakov 2015

function [phi,phix,phixx] = weightrbf_1D(xc,ind,cntr,R)

[phi,phix,phixx] = deal(zeros(size(xc,1),1));

ep = 1/R;
r = sqrt((xc-cntr).^2)*ep;

phi = (4*r+1).*(1-r).^4;
phix= 4*(r-1).^4 + 4*(4*r+1).*(r-1).^3;
phixx = 32*(r-1).^3 + 12*(4*r+1).*(r-1).^2;
    
fullind = 1:1:length(xc);
nonind = setdiff(fullind,ind);

phi(nonind) = 0;
phix(nonind) = 0;
phixx(nonind) = 0;

end

















