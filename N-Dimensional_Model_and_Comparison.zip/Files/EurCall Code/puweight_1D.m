% Define partition of unity weights using Shepard's method

%  (C) Victor Shcherbakov 2015
function [w,wx,wxx] = puweight_1D(xc,np,cntr,R,indlocpts,box)

[s,sx,sxx] = deal(zeros(size(xc,1),1));
for i = 1:np
    [phi,phix,phixx] = weightrbf_1D(xc,box(i).indlocpts,box(i).midpt,box(i).R);
    s = s + phi;
    sx = sx + phix;
    sxx = sxx + phixx;
end


[W,Wx,Wxx] = deal(zeros(size(xc,1),1));
[phi,phix,phixx] = weightrbf_1D(xc,indlocpts,cntr,R);
W =  phi./s;
Wx = phix./s - phi.*sx./s.^2;
Wxx = -2*phix.*sx./s.^2 + phixx./s + phi.*(2*sx.^2./s.^3 - sxx./s.^2);

w = W(indlocpts);
wx = Wx(indlocpts);
wxx = Wxx(indlocpts);
end