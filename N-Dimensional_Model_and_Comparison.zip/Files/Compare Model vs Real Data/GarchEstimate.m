function [VSimBar] = GarchEstimate(inputData, name)

dates = inputData{:, {'Date'}};
Mdl = garch('GARCHLags',1,'ARCHLags',1,'Offset',NaN);
EstMdl = estimate(Mdl,inputData{:, {'logReturn'}});

numObs = numel(inputData{:, {'logReturn'}}); % Sample size (T)
numPaths = 100;     % Number of paths to simulate
rng(1);             % For reproducibility
[VSim,YSim] = simulate(EstMdl,numObs,'NumPaths',numPaths);

VSimBar = mean(VSim,2);
VSimCI = quantile(VSim,[0.025 0.975],2);
YSimBar = mean(YSim,2);
YSimCI = quantile(YSim,[0.025 0.975],2);

figure;
subplot(2,1,1);
h1 = plot(dates,VSim,'Color',0.8*ones(1,3));
hold on;
h2 = plot(dates,VSimBar,'k--','LineWidth',2);
h3 = plot(dates,VSimCI,'r--','LineWidth',2);
hold off;
title(['Simulated Conditional Variances: ' name]);
ylabel('Cond. var.');
xlabel('Year');
legend([h1(1) h2 h3(1)],{'Simulated path' ['Mean: ' num2str(mean(VSimBar), '%.e')] 'Confidence bounds'},...
    'FontSize',7,'Location','NorthWest');


subplot(2,1,2);
h1 = plot(dates,YSim,'Color',0.8*ones(1,3));
hold on;
h2 = plot(dates,YSimBar,'k--','LineWidth',2);
h3 = plot(dates,YSimCI,'r--','LineWidth',2);
hold off;
title(['Simulated Log Returns: ' name]);
ylabel('Log returns');
xlabel('Year');
legend([h1(1) h2 h3(1)],{'Simulated path' ['Mean: ' num2str(mean(YSimBar), '%.e')] 'Confidence bounds'},...
    'FontSize',7,'Location','NorthWest');

end