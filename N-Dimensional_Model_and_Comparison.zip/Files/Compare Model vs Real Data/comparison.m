%% Model Data vs Real Data BSM Comparison
% Zachary Humphries
close all

global r;
r = 0.1;

tradingDays = 252;

CAC40 = rmmissing(readtable('CAC40Index.xlsx'), 'DataVariables',{'Date', 'LastPrice'});
DAX = rmmissing(readtable('DAXIndex.xlsx'), 'DataVariables',{'Date', 'LastPrice'});
% DAX100 = readtable('DAX100Index.xlsx');

% indexTables = [CAC40, DAX, DAX100];


CAC40 = logReturnRate(CAC40(:,{'Date', 'LastPrice'}));
DAX = logReturnRate(DAX(:,{'Date', 'LastPrice'}));

figure
plot(CAC40{:, {'Date'}}, CAC40{:, {'LastPrice'}})
title(['Asset Price: CAC40']);
ylabel('Price');
xlabel('Date');
figure
plot(CAC40{:, {'Date'}}, CAC40{:, {'logReturn'}})
hold on
plot(CAC40{:, {'Date'}}, CAC40{:, {'logReturnTotal'}})
title(['Log Returns: CAC40']);
ylabel('Log Return');
xlabel('Date');
legend('Daily Log Returns', 'Total Log Returns')
hold off

figure
plot(DAX{:, {'Date'}}, DAX{:, {'LastPrice'}})
title(['Asset Price: DAX']);
ylabel('Price');
xlabel('Date');
figure
plot(DAX{:, {'Date'}}, DAX{:, {'logReturn'}})
hold on
plot(DAX{:, {'Date'}}, DAX{:, {'logReturnTotal'}})
title(['Log Returns: DAX']);
ylabel('Log Return');
xlabel('Date');
legend('Daily Log Returns', 'Total Log Returns')
hold off


[sigma2SimCAC] = GarchEstimate(CAC40, 'CAC40');
callLogReturnCAC = callValue(CAC40, sigma2SimCAC);

plotCallLogReturn(CAC40, 'CAC40', callLogReturnCAC);

[sigma2SimDAX] = GarchEstimate(DAX, 'DAX');
callLogReturnDAX = callValue(DAX, sigma2SimDAX);

plotCallLogReturn(DAX, 'DAX', callLogReturnDAX);

compTable = innerjoin(CAC40, DAX, 'LeftKey', 1, 'RightKey', 1);

rho = corrcoef(compTable{:, {'logReturn_CAC40'}}, compTable{:, {'logReturn_DAX'}});
sigmas = [mean(sigma2SimCAC)*sqrt(length(CAC40{:, {'Date'}})), mean(sigma2SimDAX)*sqrt(length(DAX{:, {'Date'}}))];
sigmas2 = [std(CAC40{:, {'logReturn'}})*sqrt(length(CAC40{:, {'Date'}})), std(DAX{:, {'logReturn'}})*sqrt(length(DAX{:, {'Date'}}))];

finalOmega = [(sigmas(1) * sqrt(rho(1,1))), sqrt(sigmas(1)*sigmas(2)*rho(1,2));...
              sqrt(sigmas(1)*sigmas(2)*rho(2,1)), sqrt(sigmas(2)^2 * rho(2,2))];

finalOmega2 = [(sigmas2(1)^2 * rho(1,1)), (sigmas2(1)*sigmas2(2)*rho(1,2));...
              (sigmas2(1)*sigmas2(2)*rho(2,1)), (sigmas2(2)^2 * rho(2,2))];

function logReturn = logReturnRate(priceTable)
    
    priceTable = sortrows(priceTable, 'Date');
    
    lastPrice = priceTable{:, {'LastPrice'}};
    
    prevLastPrice = [lastPrice(1); lastPrice(1:(end-1),:)];
   
    rr = log(lastPrice) - log(prevLastPrice);
    
    rtotal = log(priceTable{:, {'LastPrice'}}) - log(priceTable{1, {'LastPrice'}});

    rr = array2table(rr, 'VariableNames', {'logReturn'});

    rtotal = array2table(rtotal, 'VariableNames', {'logReturnTotal'});

   
    logReturn = [priceTable, rr, rtotal];

end

function callMeanValueArray = callValue(inputTable, VSimBar)

    dates = inputTable{:, {'Date'}};

    sigma2 = mean(VSimBar);
    callMeanValueArray = zeros(length(dates), 1);
    
    for ii = 1:length(dates)
        annumMeanSigma = sigma2*sqrt(252);
        initialPrice = inputTable{1, {'LastPrice'}};
    
        [call, put] = blsprice(initialPrice, initialPrice, 0.1, years(dates(end)-dates(ii)), annumMeanSigma);
        callMeanValueArray(ii) = log(initialPrice + call) - log(initialPrice);
    end

end

function plotCallLogReturn(inputTable, name, callLogReturn)
    figure
    plot(flipud(inputTable{:, {'Date'}}), callLogReturn);
    hold on
    plot(inputTable{:, {'Date'}}, log(inputTable{:, {'LastPrice'}}) - log(inputTable{1, {'LastPrice'}}))
    title(['Call Value Log Returns: ' name]);
    ylabel('Log Returns');
    xlabel('Year');
    legend('BSM-1D', 'Total Log Returns')


end